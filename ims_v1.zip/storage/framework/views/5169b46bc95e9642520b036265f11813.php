<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="<?php echo e(asset('images/logo.png')); ?>" type="image/x-icon">
    <title><?php echo $__env->yieldContent('title', 'Default Title'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js', 'resources/css/app.css']); ?>
</head>
<body class="font-sans bg-gray-100">

    <!-- Navbar Component -->
    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <footer class="bg-dark-gray text-white py-8 mt-12">
        <div class="max-w-7xl mx-auto text-center">
            <p>&copy; 2024 Institute Management. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
<?php /**PATH E:\django\ims\ims_v1\resources\views/layouts/landingPage/welcome.blade.php ENDPATH**/ ?>